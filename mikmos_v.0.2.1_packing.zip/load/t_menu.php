<div class="left-sidebar">
<div class="scroll-sidebar">
<nav class="sidebar-nav">
<ul id="sidebarnav">
<li class="nav-devider"></li>
<li class="nav-label">Main Menu</li>
<li><a href="./?load=home" class=""><i class="fa fa-dashboard"></i><span class="hide-menu"><?php _e(__DASHBOARD);?></span></a></li>
<li>
<a class="has-arrow  " href="javascript:void(0)" aria-expanded="false"><i class="fa fa-wifi"></i><span class="hide-menu"><?php _e(__HOTSPOT);?></span></a>
<ul aria-expanded="false" class="collapse">
<li>
<a class="has-arrow  " href="javascript:void(0)" aria-expanded="false"><i class="fa fa-users"></i><?php _e(__USERS);?></a>
<ul aria-expanded="false" class="collapse">
<li><a href="./?load=users" class=""><i class="fa fa-list"></i> List <?php _e(__USERS);?></a></li>
<li><a href="./?load=users&get=add" class=""><i class="fa fa-plus-square"></i> <?php _e(__USERS);?></a></li>
<li><a href="./?load=users&get=generate" class=""><i class="fa fa-plus-square"></i> <?php _e(__GENERATE);?></a></li>
<li><a href="./?load=users_import" class=""><i class="fa fa-file-excel-o"></i> <?php _e(__IMPORT);?> Excel</a></li>
</ul>
</li>
<li>
<a class="has-arrow  " href="javascript:void(0)" aria-expanded="false"><i class="fa fa-tags"></i><?php _e(__PROFILE);?></a>
<ul aria-expanded="false" class="collapse">
<li><a href="./?load=profile" class=""><i class="fa fa-list-ul"></i> List <?php _e(__PROFILE);?></a></li>
<li><a href="./?load=profile&get=add" class=""><i class="fa fa-plus-square"></i> <?php _e(__PROFILE);?></a></li>
</ul>
</li>
<li><a href="./?load=users_active" class=""><i class="fa fa-smile-o"></i> <?php _e(__USERS_ACTIVE);?></a></li>
<li><a href="./?load=hosts" class=""><i class="fa fa-road"></i> <?php _e(__HOSTS);?></a></li>
<li><a href="./?load=ipbinding" class=""><i class="fa fa-code-fork"></i> <?php _e(__BINDING);?></a></li>
<li><a href="./?load=walled_garden" class=""><i class="fa fa-random"></i> <?php _e(__WALLED_GARDEN);?></a></li>
<li><a href="./?load=cookies" class=""><i class="fa fa-retweet"></i> <?php _e(__COOKIES);?></a></li>
</ul>
</li>
<li><a href="./?load=vouchers" class=""><i class="fa fa-ticket"></i><span class="hide-menu"> <?php _e(__VOUCHERS);?></span></a></li>
<li>
<a class="has-arrow  " href="javascript:void(0)" aria-expanded="false"><i class="fa fa-money"></i><span class="hide-menu"><?php _e(__BILLING);?></span></a>
<ul aria-expanded="false" class="collapse">
<li><a href="./?load=billing" class=""><i class="fa fa-line-chart"></i> <?php _e(__GRAFIK_BILLING);?></a></li>
<li><a href="./?load=billing&get=listen" class=""><i class="fa fa-table"></i> <?php _e(__TABLE_BILLING);?></a></li>
</ul>
</li>

<li><a href="./?load=users_logs" class=""><i class="fa fa-history"></i><span class="hide-menu"> <?php _e(__LOG_ACTIVITY);?></span></a></li>
<li><a href="./?load=interface" class=""><i class="fa fa-area-chart"></i><span class="hide-menu"> <?php _e(__INTERFACE);?></span></a></li>
<li>
<a class="has-arrow  " href="javascript:void(0)" aria-expanded="false"><i class="fa fa-sitemap"></i><span class="hide-menu"><?php _e(__SYSTEM);?></span></a>
<ul aria-expanded="false" class="collapse">
<li><a href="./?load=dhcp_lease" class=""><i class="fa fa-random"></i> <?php _e(__DHCPLEASE);?></a></li>
<li><a href="./?load=scheduler" class=""><i class="fa fa-calendar"></i> <?php _e(__SCHEDULER);?></a></li>
<li><a href="./settings.php?index=reboot" class=""><i class="fa fa-power-off"></i> <?php _e(__REBOOT);?></a></li>
</ul>
</li>
<li>
<a class="has-arrow  " href="javascript:void(0)" aria-expanded="false"><i class="fa fa-sliders"></i><span class="hide-menu"><?php _e(__TOOLS);?></span></a>
<ul aria-expanded="false" class="collapse">
<li><a href="./?load=netwatch" class=""><i class="fa fa-laptop"></i> <?php _e(__NETWATCH);?></a></li>
</ul>
</li>
<li>
<a class="has-arrow  " href="javascript:void(0)" aria-expanded="false"><i class="fa fa-gears"></i><span class="hide-menu"><?php _e(__ADMINISTRATOR);?></span></a>
<ul aria-expanded="false" class="collapse">
<li><a href="./settings.php?index" class=""><i class="fa fa-gear"></i> <?php _e(__SETTINGS);?></a></li>
<li><a href="./?index=backup" class=""><i class="fa fa-file-zip-o"></i> <?php _e(__BACKUP);?></a></li>
<li><a href="./?load=blok" class=""><i class="fa fa-ban"></i> <?php _e(__BLOK);?></a></li>
<li><a href="./settings.php?index=administrator" class=""><i class="fa fa-key"></i> <?php _e(__ADMIN);?></a></li>
<li><a href="./settings.php?index=mikrotik" class=""><i class="fa fa-signal"></i> <?php _e(__ROUTER);?></a></li>
<li><a href="./settings.php?index=telegram" class=""><i class="fa fa-telegram"></i> <?php _e(__TELEGRAM);?></a></li>
<li><a href="./?index=vouchers_style" class=""><i class="fa fa-ticket"></i> <?php _e(__VOUCHERS_STYLE);?></a></li>
<li><a href="./settings.php?index=update" class=""><i class="fa fa-upload"></i> <?php _e(__UPDATE);?> Manual</a></li>
</ul>
</li>
<li>
<a class="has-arrow  " href="javascript:void(0)" aria-expanded="false"><i class="fa fa-medium"></i><span class="hide-menu"><?php _e(__MIKMOS_ONLINE);?></span></a>
<ul aria-expanded="false" class="collapse">
<li><a href="./settings.php?index=srstunnel" class=""><i class="fa fa-shield"></i> <?php _e(__SRSTUNNEL);?></a></li>
<li><a href="./settings.php?index=premium" class=""><i class="fa fa-download"></i> <?php _e(__PREMIUM);?></a></li>
</ul>
</li>
<li><a href="./?load=about" class=""><i class="fa fa-code"></i> <span class="hide-menu"><?php _e(__ABOUTS);?></span></a></li>
</ul>
</nav>
</div>
</div>
<div class="page-wrapper">
<div class="container-fluid">
